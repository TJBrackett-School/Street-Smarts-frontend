export const environment = {
  // Required attributes name, email, birthdate, address
  production: false,
  COGNITO_USER_POOL_ID: 'us-east-1_73tcpLDr3',
  COGNITO_CLIENT_ID: '2pagnt2ehkg47epfd8740t5pkm',
  COGNITO_IDENTITY_POOL_ID: 'us-east-1:b293211b-7073-4a6f-8f46-337a1ff7953d',
  GOOGLE_MAPS_API_KEY: 'AIzaSyD7-djI5qqMOpOryyvvG3K8fN2ZM7IaMdQ'
};
